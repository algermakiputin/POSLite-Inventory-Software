
<script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/metisMenu/metisMenu.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/raphael/raphael.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/morrisjs/morris.min.js'); ?>"></script> 
<script src="<?php echo base_url('assets/dist/js/sb-admin-2.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/sequenceListener.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jszip.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/vsfont.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/buttons.flash.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/html.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/moment.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables-responsive/dataTables.responsive.js'); ?>"></script>

<script src="<?php echo base_url('assets/vendor/parsley.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/preview-image.js') ?>"></script> 
<script src="<?php echo base_url('assets/js/index.js') ?>"></script> 
