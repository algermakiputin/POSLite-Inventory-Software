<!DOCTYPE html>
<html>
<head>
	<title>Notice</title>
</head>
<body>
	<style type="text/css">
		body {
			position: relative;
			font-family: Arial;
		}
		#main {
			width: 25%;
			left: 25%;
			top: 45%;
			transform: translate(50%,50%);
			position: absolute;
		}

		p {
			font-size: 22px;
		}

		h2 {
			text-decoration: underline;
		}
	</style>
	<div id="main">
		<h1>Buy now the full features of this system for single user</h1>
		<h2>Contact me to get a quote</h2>
		<p>
			Facebook: <a href="https://facebook.com/hitme123" target="__blank">link</a>
		</p>
		<p>
			email: dev.algermakiputin@gmail.com
		</p>
		<p>
			Number: 09560887535
		</p>
	</div>
</body>
</html>