<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 ">
				<h2 class="text-center">Setting up database</h2>
			 
			</div>
		</div>
	</div>
</body>