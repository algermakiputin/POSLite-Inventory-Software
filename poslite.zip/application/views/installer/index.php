<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3 ">
				<h2 class="text-center">Database Setup</h2>
				<p>Step 1:</p>
			</div>
		</div>
	</div>
</body>