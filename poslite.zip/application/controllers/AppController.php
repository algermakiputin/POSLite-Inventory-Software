<?php 

class AppController extends CI_Controller {

	 public function test() {
	 	 
	 }
}
 