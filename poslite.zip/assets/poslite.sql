-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2019 at 01:06 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poslite`
--
CREATE DATABASE IF NOT EXISTS `poslite` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `poslite`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `active`) VALUES
(52, 'junkfoods', 1),
(71, 'Beverage', 1),
(81, 'soap', 1),
(91, 'yun', 1),
(101, 'junkfoods', 1),
(121, 'A', 1),
(131, 'B', 1),
(142, '123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `gender` varchar(55) NOT NULL,
  `home_address` varchar(99) NOT NULL,
  `outlet_location` varchar(100) NOT NULL,
  `outlet_address` varchar(100) NOT NULL,
  `contact_number` varchar(25) NOT NULL,
  `membership` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `gender`, `home_address`, `outlet_location`, `outlet_address`, `contact_number`, `membership`) VALUES
(1, '123123', 'male', '123', '123', '123', '123', 0),
(2, '123123', 'male', '123', '123', '123', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_details`
--

CREATE TABLE `delivery_details` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantities` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `type` varchar(55) NOT NULL,
  `cost` float NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `type`, `cost`, `date`) VALUES
(1, 'wage', 255, '2019-05-21'),
(2, '55', 5, '2019-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(150) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `user_id`, `action`, `date`) VALUES
(1, 6, 'Log in', '2018-12-30 01:36:43'),
(2, 6, 'Deleted Category: sas', '2018-12-30 01:36:48'),
(3, 6, 'Deleted Category: 123', '2018-12-30 01:36:49'),
(4, 6, 'Deleted Category: dd', '2018-12-30 01:36:51'),
(5, 6, 'Deleted Category: yun', '2018-12-30 01:43:07'),
(6, 6, 'Deleted Category: yun', '2018-12-30 01:43:10'),
(7, 6, 'Deleted Category: yun', '2018-12-30 01:43:11'),
(8, 6, 'Deleted Category: yun', '2018-12-30 01:43:12'),
(9, 6, 'Deleted Category: yun', '2018-12-30 01:43:13'),
(10, 6, 'Register Category: test', '2018-12-30 01:50:14'),
(11, 6, 'Register Category: test', '2018-12-30 01:53:40'),
(12, 6, 'Register Category: test', '2018-12-30 01:53:43'),
(13, 6, 'Deleted Category: test', '2018-12-30 01:54:33'),
(14, 6, 'Deleted Category: test', '2018-12-30 01:54:36'),
(15, 6, 'Log out', '2018-12-30 02:30:24'),
(16, 6, 'Log in', '2019-01-03 01:44:48'),
(17, 6, 'Log out', '2019-01-03 01:45:40'),
(18, 6, 'Log in', '2019-01-03 03:42:48'),
(19, 6, 'Log in', '2019-01-04 04:23:48'),
(20, 6, 'Log in', '2019-01-04 07:40:19'),
(21, 6, 'Log in', '2019-01-04 08:15:36'),
(22, 6, 'Log in', '2019-01-05 03:00:00'),
(23, 6, 'Log in', '2019-01-06 08:33:38'),
(24, 6, 'Log in', '2019-01-10 12:27:40'),
(25, 6, 'Stock In: 501 - Glaxy Note', '2019-01-10 12:29:33'),
(26, 6, 'Stock In: 1000 - Fanta 1.5 Litr', '2019-01-10 12:29:46'),
(27, 6, 'Log in', '2019-01-11 10:00:42'),
(28, 6, 'Register new item: test', '2019-01-11 10:02:46'),
(29, 6, 'Change Test 2 Description: Test to test', '2019-01-11 10:08:55'),
(30, 6, 'Log in', '2019-01-12 01:07:07'),
(31, 6, 'Log in', '2019-01-12 01:23:46'),
(32, 6, 'Log in', '2019-01-12 06:53:03'),
(33, 18, 'Log in', '2019-01-12 07:36:07'),
(34, 18, 'Log out', '2019-01-12 07:55:22'),
(35, 6, 'Log in', '2019-01-12 07:55:26'),
(36, 18, 'Log in', '2019-01-12 09:17:29'),
(37, 18, 'Log out', '2019-01-12 09:35:09'),
(38, 6, 'Log in', '2019-01-14 00:49:35'),
(39, 18, 'Log in', '2019-01-14 01:43:34'),
(40, 18, 'Log out', '2019-01-14 01:45:35'),
(41, 6, 'Log in', '2019-01-14 01:45:38'),
(42, 18, 'Log in', '2019-01-15 00:21:03'),
(43, 18, 'Log out', '2019-01-15 00:25:45'),
(44, 6, 'Log in', '2019-01-18 13:59:52'),
(45, 18, 'Log in', '2019-01-18 14:20:59'),
(46, 18, 'Log in', '2019-01-19 00:07:15'),
(47, 6, 'Log in', '2019-01-19 03:54:04'),
(48, 6, 'Log in', '2019-01-19 04:48:32'),
(49, 6, 'Log in', '2019-01-19 05:42:22'),
(50, 18, 'Log in', '2019-01-20 00:16:34'),
(51, 18, 'Log out', '2019-01-20 00:23:58'),
(52, 6, 'Log in', '2019-01-20 00:24:03'),
(53, 6, 'Change Item Name: a to Milo', '2019-01-20 00:24:35'),
(54, 6, 'Change a Price: 1 to 7', '2019-01-20 00:24:35'),
(55, 6, 'Change a Category: junkfoods to Beverage', '2019-01-20 00:24:35'),
(56, 6, 'Stock In: 50 - Piatos', '2019-01-20 00:24:53'),
(57, 6, 'Register Category: candy', '2019-01-20 00:25:16'),
(58, 6, 'Register new item: max', '2019-01-20 00:25:33'),
(59, 6, 'Stock In: 100 - max', '2019-01-20 00:25:44'),
(60, 6, 'Log in', '2019-01-24 10:00:51'),
(61, 6, 'Log in', '2019-01-28 12:02:09'),
(62, 6, 'Log in', '2019-01-30 11:38:36'),
(63, 6, 'Register new item: test', '2019-01-30 11:38:52'),
(64, 6, 'Register new item: 123123', '2019-01-30 11:46:13'),
(65, 6, 'Register new item: 123123', '2019-01-30 11:46:19'),
(66, 6, 'Register new item: qweqwe', '2019-01-30 11:47:33'),
(67, 6, 'Register new item: qweqwe', '2019-01-30 11:48:09'),
(68, 18, 'Log in', '2019-01-30 11:49:12'),
(69, 18, 'Log out', '2019-01-30 11:49:17'),
(70, 6, 'Log in', '2019-01-30 11:49:20'),
(71, 6, 'Register new item: 123123', '2019-01-30 11:49:29'),
(72, 6, 'Stock In: 22 - test', '2019-01-30 11:49:33'),
(73, 6, 'Stock In: 222 - 123123', '2019-01-30 11:49:37'),
(74, 6, 'Stock In: 222 - 123123', '2019-01-30 11:49:39'),
(75, 6, 'Stock In: 2222 - qweqwe', '2019-01-30 11:49:42'),
(76, 6, 'Stock In: 123 - qweqwe', '2019-01-30 11:49:44'),
(77, 6, 'Stock In: 123 - 123123', '2019-01-30 11:49:46'),
(78, 6, 'Register new item: qweqwe2', '2019-01-30 11:50:11'),
(79, 6, 'Register new item: 123123', '2019-01-30 11:50:17'),
(80, 6, 'Register new item: sdfsdf', '2019-01-30 11:51:02'),
(81, 6, 'Register new item: dasdqwe', '2019-01-30 11:51:17'),
(82, 6, 'Register new item: qweqws', '2019-01-30 11:52:51'),
(83, 6, 'Stock In: 123 - qweqwe2', '2019-01-30 11:52:55'),
(84, 6, 'Stock In: 22 - 123123', '2019-01-30 11:52:59'),
(85, 6, 'Stock In: 12 - sdfsdf', '2019-01-30 11:53:01'),
(86, 6, 'Stock In: 22 - dasdqwe', '2019-01-30 11:53:03'),
(87, 6, 'Stock In: 22 - qweqws', '2019-01-30 11:53:06'),
(88, 6, 'Log in', '2019-01-31 13:06:37'),
(89, 6, 'Log in', '2019-02-01 05:32:59'),
(90, 18, 'Log in', '2019-02-08 09:56:32'),
(91, 18, 'Log in', '2019-02-08 10:16:38'),
(92, 18, 'Log out', '2019-02-08 10:26:02'),
(93, 6, 'Log in', '2019-02-08 10:26:18'),
(94, 6, 'Log in', '2019-02-08 10:36:53'),
(95, 6, 'Log in', '2019-02-09 06:50:18'),
(96, 6, 'Log in', '2019-02-10 09:39:12'),
(97, 6, 'Log out', '2019-02-10 09:39:26'),
(98, 18, 'Log in', '2019-02-10 09:39:30'),
(99, 18, 'Log out', '2019-02-10 09:39:33'),
(100, 6, 'Log in', '2019-02-10 09:39:39'),
(101, 6, 'Log out', '2019-02-10 09:39:42'),
(102, 18, 'Log in', '2019-02-10 09:40:18'),
(103, 18, 'Log in', '2019-02-10 09:44:57'),
(104, 6, 'Log in', '2019-02-10 10:13:44'),
(105, 6, 'Log in', '2019-02-13 01:35:58'),
(106, 6, 'Log in', '2019-02-13 07:34:52'),
(107, 6, 'Log in', '2019-02-13 07:40:49'),
(108, 6, 'Delete Item: Cotton Buds', '2019-02-13 07:41:06'),
(109, 6, 'Delete Item: Ethyl Alcohol', '2019-02-13 07:41:08'),
(110, 6, 'Delete Item: Cotton', '2019-02-13 07:41:09'),
(111, 6, 'Delete Item: Jelly', '2019-02-13 07:41:11'),
(112, 6, 'Delete Item: qweqwe', '2019-02-13 07:41:12'),
(113, 6, 'Delete Item: qweqws', '2019-02-13 07:43:45'),
(114, 6, 'Delete Item: dasdqwe', '2019-02-13 07:43:47'),
(115, 6, 'Delete Item: sdfsdf', '2019-02-13 07:43:48'),
(116, 6, 'Delete Item: 123123', '2019-02-13 07:43:50'),
(117, 6, 'Delete Item: qweqwe2', '2019-02-13 07:43:52'),
(118, 6, 'Delete Item: 123123', '2019-02-13 07:43:53'),
(119, 6, 'Log in', '2019-02-18 08:40:46'),
(120, 6, 'Register new item: alger', '2019-02-18 08:43:11'),
(121, 6, 'Log in', '2019-02-20 07:53:31'),
(122, 6, 'Log out', '2019-02-20 07:53:49'),
(123, 6, 'Log in', '2019-02-20 07:54:30'),
(124, 6, 'Log in', '2019-02-20 08:48:07'),
(125, 6, 'Log in', '2019-02-20 08:48:34'),
(126, 6, 'Log out', '2019-02-20 09:24:02'),
(127, 6, 'Log in', '2019-02-20 09:24:49'),
(128, 6, 'Log out', '2019-02-20 09:28:57'),
(129, 6, 'Log in', '2019-02-20 11:24:37'),
(130, 6, 'Log out', '2019-02-20 11:28:05'),
(131, 6, 'Log in', '2019-02-20 11:28:09'),
(132, 6, 'Log out', '2019-02-20 11:28:26'),
(133, 20, 'Log in', '2019-02-20 11:28:34'),
(134, 20, 'Log out', '2019-02-20 11:28:40'),
(135, 6, 'Log in', '2019-02-20 11:29:11'),
(136, 6, 'Log in', '2019-02-24 09:45:07'),
(137, 6, 'Log out', '2019-02-24 09:47:37'),
(138, 6, 'Log in', '2019-02-24 09:47:40'),
(139, 6, 'Log out', '2019-02-24 09:48:20'),
(140, 6, 'Log in', '2019-02-24 23:51:46'),
(141, 6, 'Log out', '2019-02-24 23:52:28'),
(142, 17, 'Log in', '2019-02-24 23:52:37'),
(143, 6, 'Log in', '2019-02-24 23:52:42'),
(144, 6, 'Log out', '2019-02-24 23:52:46'),
(145, 6, 'Log in', '2019-02-24 23:52:57'),
(146, 6, 'Log out', '2019-02-24 23:53:11'),
(147, 20, 'Log in', '2019-02-24 23:53:14'),
(148, 20, 'Delete Item: alger', '2019-02-24 23:55:19'),
(149, 6, 'Log in', '2019-02-27 00:17:27'),
(150, 6, 'Log in', '2019-02-28 08:50:11'),
(151, 6, 'Register new item: test', '2019-02-28 08:50:27'),
(152, 6, 'Stock In: 100 - alger', '2019-02-28 08:50:42'),
(153, 6, 'Stock In: 100 - test', '2019-02-28 08:50:46'),
(154, 6, 'Delete Item: alger', '2019-02-28 08:51:12'),
(155, 20, 'Log in', '2019-02-28 12:49:19'),
(156, 6, 'Log in', '2019-03-06 00:27:53'),
(157, 6, 'Register new item: 123123', '2019-03-06 00:33:11'),
(158, 6, 'Register new item: 123', '2019-03-06 00:33:40'),
(159, 6, 'Register new item: 123', '2019-03-06 00:34:12'),
(160, 6, 'Register new item: 123', '2019-03-06 00:34:18'),
(161, 6, 'Register new item: 123', '2019-03-06 00:34:55'),
(162, 6, 'Register new item: 123', '2019-03-06 00:35:21'),
(163, 6, 'Register new item: 123', '2019-03-06 00:35:55'),
(164, 6, 'Register new item: 123123', '2019-03-06 00:36:35'),
(165, 6, 'Register new item: 123', '2019-03-06 00:36:59'),
(166, 6, 'Delete Item: 123', '2019-03-06 00:37:00'),
(167, 6, 'Register new item: 123', '2019-03-06 00:38:19'),
(168, 6, 'Delete Item: 123', '2019-03-06 00:38:22'),
(169, 6, 'Register new item: 123', '2019-03-06 00:38:35'),
(170, 6, 'Delete Item: 123', '2019-03-06 00:38:38'),
(171, 6, 'Register new item: 123123', '2019-03-06 00:40:14'),
(172, 6, 'Register new item: 123123', '2019-03-06 00:40:29'),
(173, 6, 'Delete Item: 123123', '2019-03-06 00:40:34'),
(174, 6, 'Delete Item: 123123', '2019-03-06 00:41:21'),
(175, 6, 'Register new item: 23123', '2019-03-06 00:43:59'),
(176, 6, 'Delete Item: 23123', '2019-03-06 00:46:31'),
(177, 6, 'Register new item: 555', '2019-03-06 00:49:56'),
(178, 6, 'Change Item Name: 555 to Corneto', '2019-03-06 00:56:38'),
(179, 6, 'Change 555 Description: 555 to ice cream', '2019-03-06 00:56:38'),
(180, 6, 'Change 555 Price: 555 to 25', '2019-03-06 00:56:38'),
(181, 6, 'Change 555 Category: junkfoods to Beverage', '2019-03-06 00:56:38'),
(182, 6, 'Stock In: 100 - Corneto', '2019-03-06 00:58:12'),
(183, 6, 'Log in', '2019-03-11 02:40:08'),
(184, 6, 'Log in', '2019-03-16 00:17:39'),
(191, 6, 'Log in', '2019-03-16 00:28:55'),
(201, 6, 'Log in', '2019-03-16 01:45:17'),
(211, 6, 'Log in', '2019-03-16 04:59:00'),
(221, 6, 'Log in', '2019-03-16 05:10:50'),
(231, 6, 'Stock In: 1 - Corneto', '2019-03-16 05:14:41'),
(241, 6, 'Stock In: 4 - Corneto', '2019-03-16 05:15:05'),
(251, 6, 'Log out', '2019-03-16 05:16:06'),
(261, 20, 'Log in', '2019-03-16 05:16:29'),
(271, 20, 'Log out', '2019-03-16 05:17:19'),
(281, 6, 'Log in', '2019-03-16 05:24:59'),
(291, 6, 'Log out', '2019-03-16 05:26:36'),
(301, 6, 'Log in', '2019-03-16 05:26:57'),
(311, 6, 'Log in', '2019-03-16 06:17:16'),
(321, 6, 'Log in', '2019-03-16 06:32:11'),
(331, 6, 'Log in', '2019-03-16 06:34:27'),
(341, 6, 'Log out', '2019-03-16 06:35:20'),
(351, 6, 'Log out', '2019-03-16 06:36:13'),
(361, 6, 'Log in', '2019-03-16 07:38:05'),
(371, 6, 'Log in', '2019-03-16 09:05:09'),
(381, 6, 'Log in', '2019-03-16 09:25:58'),
(391, 6, 'Log in', '2019-03-16 10:31:35'),
(401, 6, 'Log in', '2019-03-16 11:45:50'),
(411, 6, 'Log in', '2019-03-16 17:45:33'),
(421, 6, 'Register Category: junkfoods', '2019-03-16 17:46:26'),
(431, 6, 'Log out', '2019-03-16 17:46:35'),
(441, 6, 'Log in', '2019-03-16 18:06:02'),
(451, 6, 'Change Corneto Price: 25 to 30', '2019-03-16 18:06:25'),
(461, 6, 'Log out', '2019-03-16 18:06:37'),
(471, 6, 'Log in', '2019-03-16 20:36:29'),
(481, 6, 'Log in', '2019-03-17 00:35:43'),
(491, 20, 'Log in', '2019-03-17 01:08:18'),
(501, 20, 'Log out', '2019-03-17 01:08:53'),
(511, 6, 'Log in', '2019-03-17 05:31:09'),
(521, 6, 'Log out', '2019-03-17 05:31:26'),
(531, 6, 'Log in', '2019-03-17 05:37:09'),
(541, 6, 'Log in', '2019-03-17 05:52:08'),
(551, 6, 'Log out', '2019-03-17 05:53:18'),
(561, 6, 'Log in', '2019-03-17 05:57:05'),
(571, 6, 'Log out', '2019-03-17 05:58:06'),
(581, 6, 'Log in', '2019-03-17 06:32:21'),
(591, 6, 'Log in', '2019-03-17 06:33:05'),
(601, 6, 'Log in', '2019-03-17 06:44:22'),
(611, 6, 'Log in', '2019-03-17 07:08:18'),
(621, 6, 'Log out', '2019-03-17 07:09:13'),
(631, 6, 'Log in', '2019-03-17 07:09:43'),
(641, 6, 'Log in', '2019-03-17 07:45:54'),
(651, 6, 'Change Corneto Description: ice cream to ice drop', '2019-03-17 07:47:05'),
(661, 6, 'Register Category: Benhar', '2019-03-17 07:47:55'),
(671, 6, 'Deleted Category: Benhar', '2019-03-17 07:47:59'),
(681, 6, 'Register Category: A', '2019-03-17 07:48:12'),
(691, 6, 'Register Category: B', '2019-03-17 07:48:17'),
(701, 6, 'Register Category: C', '2019-03-17 07:48:22'),
(711, 6, 'Log in', '2019-03-17 08:29:16'),
(721, 6, 'Log out', '2019-03-17 08:32:18'),
(731, 6, 'Log in', '2019-03-17 08:32:32'),
(741, 6, 'Log out', '2019-03-17 08:57:24'),
(751, 20, 'Log in', '2019-03-17 08:57:34'),
(761, 20, 'Log out', '2019-03-17 08:58:33'),
(771, 6, 'Log in', '2019-03-17 08:58:42'),
(781, 6, 'Log in', '2019-03-17 09:06:28'),
(791, 6, 'Stock In: 5 - Corneto', '2019-03-17 09:07:48'),
(801, 6, 'Log out', '2019-03-17 09:21:37'),
(811, 6, 'Log in', '2019-03-17 09:36:51'),
(821, 6, 'Log in', '2019-03-17 09:37:29'),
(831, 6, 'Log in', '2019-03-17 09:54:10'),
(841, 6, 'Log in', '2019-03-17 10:55:39'),
(851, 6, 'Log in', '2019-03-17 11:54:12'),
(861, 6, 'Log in', '2019-03-17 11:56:29'),
(871, 6, 'Log out', '2019-03-17 11:56:48'),
(881, 6, 'Log in', '2019-03-17 12:00:10'),
(891, 6, 'Log in', '2019-03-17 12:36:26'),
(901, 20, 'Log in', '2019-03-17 12:42:05'),
(911, 6, 'Log in', '2019-03-17 12:56:00'),
(921, 6, 'Stock In: 22 - Corneto', '2019-03-17 12:57:28'),
(931, 6, 'Register new item: Weed', '2019-03-17 12:58:21'),
(941, 6, 'Log out', '2019-03-17 12:58:59'),
(951, 20, 'Log in', '2019-03-17 12:59:19'),
(961, 20, 'Log out', '2019-03-17 12:59:47'),
(971, 6, 'Log in', '2019-03-17 13:00:04'),
(981, 6, 'Delete Item: Weed', '2019-03-17 13:00:23'),
(991, 6, 'Log out', '2019-03-17 13:00:42'),
(1001, 6, 'Log in', '2019-03-17 13:52:08'),
(1011, 6, 'Log in', '2019-03-17 14:14:34'),
(1021, 6, 'Log in', '2019-03-17 15:13:11'),
(1031, 6, 'Log in', '2019-03-17 15:38:58'),
(1041, 6, 'Log out', '2019-03-17 15:39:53'),
(1051, 20, 'Log in', '2019-03-17 15:40:10'),
(1061, 20, 'Log out', '2019-03-17 15:42:26'),
(1071, 6, 'Log in', '2019-03-17 15:42:50'),
(1081, 6, 'Log in', '2019-03-17 19:40:18'),
(1091, 6, 'Stock In: 500 - Corneto', '2019-03-17 19:54:17'),
(1101, 6, 'Register new item: 12312312312', '2019-03-17 19:55:52'),
(1111, 6, 'Log in', '2019-03-17 19:58:54'),
(1121, 6, 'Log in', '2019-03-17 23:53:05'),
(1131, 6, 'Log in', '2019-03-17 23:54:58'),
(1141, 6, 'Log in', '2019-03-17 23:57:48'),
(1151, 6, 'Stock In: 2 - 12312312312', '2019-03-17 23:58:01'),
(1161, 6, 'Log in', '2019-03-18 00:36:29'),
(1171, 6, 'Log in', '2019-03-18 03:22:47'),
(1181, 6, 'Log in', '2019-03-18 03:28:30'),
(1191, 6, 'Log out', '2019-03-18 03:31:23'),
(1201, 6, 'Log in', '2019-03-18 05:46:54'),
(1211, 6, 'Log in', '2019-03-18 10:55:18'),
(1221, 6, 'Delete Item: Corneto', '2019-03-18 10:56:10'),
(1231, 6, 'Delete Item: 12312312312', '2019-03-18 10:56:14'),
(1241, 6, 'Register new item: test', '2019-03-18 10:57:31'),
(1251, 6, 'Log out', '2019-03-18 10:57:36'),
(1261, 6, 'Log in', '2019-03-18 10:57:46'),
(1271, 6, 'Stock In: 500 - test', '2019-03-18 10:58:25'),
(1281, 6, 'Log out', '2019-03-18 10:59:30'),
(1291, 20, 'Log in', '2019-03-18 11:07:56'),
(1301, 20, 'Log out', '2019-03-18 11:08:07'),
(1311, 6, 'Log in', '2019-03-18 11:08:11'),
(1321, 6, 'Change Item Name: test to GoPro', '2019-03-18 11:08:52'),
(1331, 6, 'Register new item: case ', '2019-03-18 11:15:51'),
(1341, 6, 'Stock In: 255 - case ', '2019-03-18 11:15:57'),
(1351, 6, 'Register new item: Case Fan', '2019-03-18 11:16:32'),
(1361, 6, 'Register new item: Bingka', '2019-03-18 11:16:49'),
(1371, 6, 'Stock In: 25 - Case Fan', '2019-03-18 11:16:53'),
(1381, 6, 'Stock In: 25 - Bingka', '2019-03-18 11:16:57'),
(1391, 20, 'Log in', '2019-03-18 11:24:43'),
(1401, 20, 'Log in', '2019-03-18 11:25:01'),
(1411, 6, 'Log in', '2019-03-18 11:34:15'),
(1421, 6, 'Log in', '2019-03-18 11:54:17'),
(1431, 6, 'Log out', '2019-03-18 11:54:43'),
(1441, 20, 'Log in', '2019-03-18 11:54:55'),
(1451, 6, 'Log out', '2019-03-18 12:12:55'),
(1461, 6, 'Log in', '2019-03-18 12:18:37'),
(1471, 6, 'Log out', '2019-03-18 12:26:01'),
(1481, 6, 'Log in', '2019-03-18 12:29:35'),
(1491, 6, 'Log in', '2019-03-18 12:54:59'),
(1501, 6, 'Log in', '2019-03-18 13:08:09'),
(1511, 6, 'Log in', '2019-03-18 15:11:58'),
(1521, 6, 'Log in', '2019-03-18 15:46:34'),
(1531, 6, 'Log in', '2019-03-18 17:25:39'),
(1541, 6, 'Log in', '2019-03-18 17:34:38'),
(1551, 6, 'Log in', '2019-03-18 17:42:35'),
(1561, 6, 'Log in', '2019-03-18 19:54:16'),
(1571, 6, 'Log in', '2019-03-18 21:07:03'),
(1581, 6, 'Log in', '2019-03-18 23:10:19'),
(1591, 6, 'Log in', '2019-03-19 00:19:29'),
(1601, 6, 'Log in', '2019-03-19 00:29:03'),
(1611, 6, 'Log in', '2019-03-19 01:10:04'),
(1621, 6, 'Log in', '2019-03-19 01:35:09'),
(1631, 20, 'Log in', '2019-03-19 02:28:04'),
(1641, 20, 'Log out', '2019-03-19 02:28:36'),
(1651, 20, 'Log in', '2019-03-19 02:28:41'),
(1661, 20, 'Log out', '2019-03-19 02:28:44'),
(1671, 6, 'Log in', '2019-03-19 02:28:48'),
(1681, 6, 'Log in', '2019-03-19 02:39:59'),
(1682, 6, 'Log in', '2019-03-19 03:58:53'),
(1683, 6, 'Log in', '2019-03-20 07:53:17'),
(1684, 6, 'Change GoPro Price: 300 to 3000', '2019-03-20 07:53:27'),
(1685, 6, 'Log in', '2019-03-23 11:12:25'),
(1686, 6, 'Log in', '2019-03-25 00:33:19'),
(1687, 6, 'Log out', '2019-03-25 00:37:48'),
(1688, 6, 'Log in', '2019-03-31 04:13:04'),
(1689, 6, 'Log in', '2019-04-03 08:29:11'),
(1690, 6, 'Log out', '2019-04-03 08:38:08'),
(1691, 6, 'Log in', '2019-04-03 08:43:04'),
(1692, 6, 'Log in', '2019-04-03 08:47:54'),
(1693, 6, 'Log in', '2019-04-03 08:54:46'),
(1694, 6, 'Register new item: 123123', '2019-04-03 09:09:46'),
(1695, 6, 'Stock In: 55 - 123123', '2019-04-03 09:31:03'),
(1696, 6, 'Log out', '2019-04-03 09:45:34'),
(1697, 6, 'Log in', '2019-04-03 09:45:38'),
(1698, 6, 'Log in', '2019-04-04 01:10:54'),
(1699, 6, 'Register Category: 123', '2019-04-04 01:12:07'),
(1700, 6, 'Deleted Category: C', '2019-04-04 01:12:10'),
(1701, 6, 'Deleted Category: candy', '2019-04-04 01:12:13'),
(1702, 6, 'Stock In: 25 - GoPro', '2019-04-04 01:13:20'),
(1703, 6, 'Stock In: 25 - Case Fan', '2019-04-04 01:13:28'),
(1704, 6, 'Log in', '2019-04-04 01:24:15'),
(1705, 6, 'Log in', '2019-04-04 01:25:32'),
(1706, 6, 'Log in', '2019-04-05 23:25:37'),
(1707, 6, 'Log in', '2019-04-05 23:27:56'),
(1708, 6, 'Log in', '2019-04-05 23:39:42'),
(1709, 6, 'Log in', '2019-04-05 23:42:53'),
(1710, 6, 'Log in', '2019-04-05 23:50:28'),
(1711, 6, 'Log in', '2019-04-05 23:56:44'),
(1712, 6, 'Log in', '2019-04-05 23:58:51'),
(1713, 6, 'Log in', '2019-04-06 00:01:38'),
(1714, 6, 'Log in', '2019-04-06 00:03:30'),
(1715, 6, 'Log out', '2019-04-06 00:13:13'),
(1716, 6, 'Log in', '2019-04-06 00:14:01'),
(1717, 6, 'Log in', '2019-04-06 04:48:49'),
(1718, 6, 'Register new item: test', '2019-04-07 11:28:28'),
(1719, 6, 'Log in', '2019-04-08 02:30:21'),
(1720, 6, 'Register new item: 123asd', '2019-04-08 03:09:43'),
(1721, 6, 'Register new item: 112', '2019-04-08 03:14:55'),
(1722, 6, 'Register new item: 125', '2019-04-08 03:41:16'),
(1723, 6, 'Register new item: 12', '2019-04-08 03:47:37'),
(1724, 6, 'Log in', '2019-04-08 08:52:59'),
(1725, 6, 'Delete Item: GoPro', '2019-04-08 09:21:12'),
(1726, 6, 'Delete Item: case ', '2019-04-08 09:21:14'),
(1727, 6, 'Delete Item: Case Fan', '2019-04-08 09:21:16'),
(1728, 6, 'Delete Item: Bingka', '2019-04-08 09:21:18'),
(1729, 6, 'Delete Item: 123123', '2019-04-08 09:21:20'),
(1730, 6, 'Delete Item: test', '2019-04-08 09:21:27'),
(1731, 6, 'Stock In: 100 - 125', '2019-04-08 09:21:38'),
(1732, 6, 'Stock In: 100 - 12', '2019-04-08 09:21:42'),
(1733, 6, 'Change 125 Price: 2 to 150', '2019-04-08 09:25:35'),
(1734, 6, 'Change 12 Price: 2 to 80', '2019-04-08 09:27:35'),
(1735, 6, 'Register new item: Canon Camera', '2019-04-08 09:34:10'),
(1736, 6, 'Register new item: Apple Iphone ', '2019-04-08 09:35:01'),
(1737, 6, 'Delete Item: 12', '2019-04-08 09:45:04'),
(1738, 6, 'Delete Item: 125', '2019-04-08 09:45:07'),
(1739, 6, 'Change Canon Camera Description: Cannon Camera Black to cannon camera black', '2019-04-08 09:45:14'),
(1740, 6, 'Register new item: Headset', '2019-04-08 09:46:07'),
(1741, 6, 'Register new item: Watcch Unisex', '2019-04-08 09:46:54'),
(1742, 6, 'Register new item: Motor Engine', '2019-04-08 09:51:10'),
(1743, 6, 'Register new item: Motor Engine', '2019-04-08 09:52:02'),
(1744, 6, 'Register new item: 123', '2019-04-08 09:52:43'),
(1745, 6, 'Stock In: 25 - Canon Camera', '2019-04-08 09:53:08'),
(1746, 6, 'Stock In: 22 - Apple Iphone ', '2019-04-08 09:53:12'),
(1747, 6, 'Register new item: qweqwe', '2019-04-08 09:54:19'),
(1748, 6, 'Register new item: Motor Engine', '2019-04-08 09:56:29'),
(1749, 6, 'Register new item: Motor Engine', '2019-04-08 09:57:15'),
(1750, 6, 'Change Motor Engine Description: Motor Engine to motor engine', '2019-04-08 09:57:21'),
(1751, 6, 'Delete Item: Motor Engine', '2019-04-08 10:01:37'),
(1752, 6, 'Stock In: 100 - Motor Engine', '2019-04-08 10:01:47'),
(1753, 6, 'Stock In: 100 - Watcch Unisex', '2019-04-08 10:01:51'),
(1754, 6, 'Stock In: 100 - Headset', '2019-04-08 10:01:55'),
(1755, 6, 'Register new item: Buko ', '2019-04-08 10:02:50'),
(1756, 6, 'Change Buko  Description: Buko  to buko ', '2019-04-08 10:02:58'),
(1757, 6, 'Stock In: 100 - Buko ', '2019-04-08 10:03:40'),
(1758, 6, 'Log in', '2019-04-08 12:42:19'),
(1759, 20, 'Log in', '2019-04-09 00:28:28'),
(1760, 6, 'Log in', '2019-04-17 03:26:01'),
(1761, 6, 'Log in', '2019-04-17 04:02:42'),
(1762, 6, 'Log in', '2019-04-17 11:45:53'),
(1763, 6, 'Log in', '2019-04-17 12:22:14'),
(1764, 6, 'Log out', '2019-04-17 12:22:23'),
(1765, 6, 'Log in', '2019-04-17 12:24:21'),
(1766, 6, 'Log in', '2019-04-18 00:25:50'),
(1767, 6, 'Log in', '2019-04-18 03:41:35'),
(1768, 6, 'Log in', '2019-04-25 02:45:31'),
(1769, 6, 'Log in', '2019-04-26 06:34:44'),
(1770, 6, 'Register new item: 124124124', '2019-04-26 06:37:08'),
(1771, 6, 'Stock In: 123 - 124124124', '2019-04-26 06:37:20'),
(1772, 6, 'Delete Item: 124124124', '2019-04-26 07:04:34'),
(1773, 6, 'Log in', '2019-05-03 02:38:05'),
(1774, 6, 'Log in', '2019-05-03 03:30:42'),
(1775, 6, 'Log in', '2019-05-04 06:00:12'),
(1776, 6, 'Log in', '2019-05-04 06:35:30'),
(1777, 6, 'Log in', '2019-05-04 12:18:07'),
(1778, 6, 'Log in', '2019-05-05 03:51:23'),
(1779, 6, 'Register new item: test', '2019-05-05 03:57:47'),
(1780, 6, 'Delete Item: alger', '2019-05-05 04:01:59'),
(1781, 6, 'Delete Item: test', '2019-05-05 04:02:15'),
(1782, 6, 'Register new item: test alger', '2019-05-05 04:02:28'),
(1783, 6, 'Change Item Name: test alger to test alger2', '2019-05-05 04:04:46'),
(1784, 20, 'Log in', '2019-05-06 13:10:38'),
(1785, 6, 'Log in', '2019-05-18 12:20:18'),
(1786, 6, 'Log in', '2019-05-18 12:20:45'),
(1787, 6, 'Log in', '2019-05-18 12:28:47'),
(1788, 6, 'Log in', '2019-05-21 10:12:06'),
(1789, 6, 'Log in', '2019-05-28 12:18:12'),
(1790, 6, 'Log in', '2019-05-28 12:22:02'),
(1791, 6, 'Log in', '2019-06-01 10:17:17'),
(1792, 21, 'Log in', '2019-06-01 10:17:25'),
(1793, 6, 'Log in', '2019-06-01 10:17:46'),
(1794, 6, 'Log in', '2019-06-01 10:20:46'),
(1795, 20, 'Log in', '2019-06-01 10:21:13'),
(1796, 22, 'Log in', '2019-06-01 10:23:23'),
(1797, 6, 'Log in', '2019-06-01 23:05:39'),
(1798, 6, 'Log in', '2019-06-01 23:05:54');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `barcode` varchar(55) NOT NULL,
  `name` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `barcode`, `name`, `category_id`, `description`, `supplier_id`, `status`, `created_at`, `image`) VALUES
(76, '16126126123', 'Canon Camera', 71, 'cannon camera black', 8, 1, '2019-04-08 09:34:10', '319de1c71c07eec5468e81e48f459d10.jpg'),
(77, '12312512566', 'Apple Iphone ', 71, 'test', 9, 1, '2019-04-08 09:35:01', 'f0775739d5744f1dcc958c956721f6db.jpg'),
(78, 'A2205001', 'Headset', 71, 'Headset Color Red', 8, 1, '2019-04-08 09:46:07', '892f0cb84be792d5ffc87b067cd0b155.jpg'),
(79, 'WA5201CH', 'Watcch Unisex', 71, 'Test', 8, 1, '2019-04-08 09:46:54', 'a39e258bd7751f38ad9f4d63ba03ce9c.png'),
(80, 'A2A525', 'Motor Engine', 71, 'motor engine', 8, 1, '2019-04-08 09:56:29', 'f6cdf525fcb4988479c99cc442ae6fac.jpg'),
(82, 'A55BUKO', 'Buko ', 71, 'buko ', 8, 1, '2019-04-08 10:02:50', 'b39fbc4d7fda58e393abe36f5ba13f08.jpeg'),
(86, '500299', 'test alger2', 52, 'test alger', 8, 1, '2019-05-05 04:02:28', '');

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `date_open` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `date_open`, `customer_id`, `active`, `created_at`, `expiry_date`) VALUES
(10, '2019-01-12', 8, 1, '2019-01-02 11:02:13', '2022-01-12'),
(11, '2019-01-11', 9, 1, '2019-01-11 11:32:17', '2022-01-11'),
(12, '2019-01-12', 10, 1, '2019-01-12 01:08:30', '2022-01-12'),
(13, '2019-01-12', 11, 1, '2019-01-12 06:53:12', '2022-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `ordering_level`
--

CREATE TABLE `ordering_level` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordering_level`
--

INSERT INTO `ordering_level` (`id`, `quantity`, `item_id`) VALUES
(78, 3, 76),
(79, 21, 77),
(80, 98, 78),
(81, 98, 79),
(82, 99, 80),
(84, 99, 82),
(86, 0, 86);

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(11) NOT NULL,
  `price` double NOT NULL,
  `capital` float NOT NULL,
  `item_id` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `price`, `capital`, `item_id`, `date_time`, `status`) VALUES
(78, 30000, 25000, 76, '2019-04-08 09:34:10', 1),
(79, 1000, 555, 77, '2019-04-08 09:35:01', 1),
(80, 2000, 1500, 78, '2019-04-08 09:46:07', 0),
(81, 1000, 520, 79, '2019-04-08 09:46:54', 0),
(82, 3000, 1500, 80, '2019-04-08 09:56:29', 1),
(84, 50, 25, 82, '2019-04-08 10:02:50', 1),
(86, 5, 5, 86, '2019-05-05 04:02:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `date_time`) VALUES
(1, '2019-03-06 00:58:27'),
(11, '2019-03-16 05:12:40'),
(21, '2019-03-16 05:17:01'),
(31, '2019-03-16 10:36:47'),
(41, '2019-03-16 10:37:19'),
(51, '2019-03-16 10:37:38'),
(61, '2019-03-17 08:54:08'),
(71, '2019-03-17 15:40:40'),
(81, '2019-03-17 15:41:34'),
(91, '2019-03-17 19:45:23'),
(101, '2019-03-17 23:53:46'),
(111, '2019-03-18 11:43:17'),
(121, '2019-03-18 11:55:14'),
(131, '2019-03-18 15:13:09'),
(141, '2019-03-18 18:30:53'),
(151, '2019-03-18 18:32:25'),
(161, '2019-03-19 00:59:44'),
(171, '2019-03-19 02:28:29'),
(172, '2019-03-19 03:59:13'),
(173, '2019-04-03 09:34:19'),
(174, '2019-04-05 23:28:05'),
(175, '2019-04-05 23:29:00'),
(176, '2019-04-08 09:18:03'),
(177, '2019-04-08 09:22:00'),
(178, '2019-04-08 09:27:42'),
(179, '2019-04-25 02:46:13'),
(180, '2019-04-26 06:37:32'),
(181, '2019-04-26 06:52:57'),
(182, '2019-04-26 06:57:44'),
(183, '2019-04-26 07:00:33'),
(184, '2019-04-26 07:01:41'),
(185, '2019-04-26 07:04:17'),
(186, '2019-04-30 16:00:00'),
(187, '2019-05-03 02:50:32'),
(188, '2019-05-18 00:20:58'),
(189, '2019-05-18 00:22:11');

-- --------------------------------------------------------

--
-- Table structure for table `sales_description`
--

CREATE TABLE `sales_description` (
  `id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `price` float NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `discount` int(11) NOT NULL,
  `profit` float NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_description`
--

INSERT INTO `sales_description` (`id`, `sales_id`, `quantity`, `item_id`, `created_at`, `price`, `name`, `discount`, `profit`, `user_id`) VALUES
(11, 11, 1, 18, '2019-03-16 05:12:40', 25, 'Corneto', 0, 0, 0),
(21, 21, 2, 18, '2019-03-16 05:17:01', 25, 'Corneto', 0, 0, 0),
(31, 31, 6, 18, '2019-03-16 10:36:47', 25, 'Corneto', 0, 0, 0),
(41, 41, 64, 18, '2019-03-16 10:37:19', 25, 'Corneto', 0, 0, 0),
(51, 51, 9, 18, '2019-03-16 10:37:38', 25, 'Corneto', 0, 0, 0),
(61, 61, 23, 18, '2019-03-17 08:54:08', 30, 'Corneto', 0, 0, 0),
(71, 71, 1, 18, '2019-03-17 15:40:40', 30, 'Corneto', 0, 0, 0),
(81, 81, 1, 18, '2019-03-17 15:41:34', 30, 'Corneto', 0, 0, 0),
(91, 91, 25, 18, '2019-03-17 19:45:23', 30, 'Corneto', 0, 0, 0),
(101, 101, 1, 18, '2019-03-17 23:53:46', 30, 'Corneto', 0, 0, 0),
(111, 111, 1, 41, '2019-03-18 11:43:17', 300, 'GoPro', 0, 0, 0),
(121, 121, 1, 41, '2019-03-18 11:55:14', 300, 'GoPro', 0, 0, 0),
(131, 121, 1, 51, '2019-03-18 11:55:14', 25, 'Case ', 0, 0, 0),
(141, 121, 1, 61, '2019-03-18 11:55:14', 250, 'Case Fan', 0, 0, 0),
(151, 131, 1, 41, '2019-03-18 15:13:09', 300, 'GoPro', 0, 0, 0),
(161, 141, 4, 41, '2019-03-18 18:30:53', 300, 'GoPro', 0, 0, 0),
(171, 151, 1, 51, '2019-03-18 18:32:25', 25, 'Case ', 0, 0, 0),
(181, 151, 1, 61, '2019-03-18 18:32:25', 250, 'Case Fan', 0, 0, 0),
(191, 161, 100, 41, '2019-03-19 00:59:44', 300, 'GoPro', 0, 0, 0),
(201, 171, 1, 51, '2019-03-19 02:28:29', 25, 'Case ', 0, 0, 20),
(211, 171, 1, 41, '2019-03-19 02:28:29', 300, 'GoPro', 0, 0, 20),
(221, 171, 1, 61, '2019-03-19 02:28:29', 250, 'Case Fan', 25, 0, 20),
(231, 171, 1, 71, '2019-03-19 02:28:29', 5, 'Bingka', 0, 0, 20),
(232, 172, 1, 41, '2019-03-19 03:59:13', 300, 'GoPro', 10, 0, 6),
(233, 172, 1, 51, '2019-03-19 03:59:13', 25, 'Case ', 0, 0, 6),
(234, 172, 1, 61, '2019-03-19 03:59:13', 250, 'Case Fan', 0, 0, 6),
(235, 172, 1, 71, '2019-03-19 03:59:13', 5, 'Bingka', 0, 0, 6),
(236, 187, 1, 78, '2019-05-03 02:50:32', 2000, 'Headset', 0, 1500, 6),
(237, 187, 1, 79, '2019-05-03 02:50:32', 1000, 'Watcch Unisex', 0, 520, 6),
(238, 187, 1, 80, '2019-05-03 02:50:32', 3000, 'Motor Engine', 250, 1500, 6),
(239, 188, 1, 77, '2019-05-18 12:20:58', 1000, 'Apple Iphone ', 0, 555, 6),
(240, 188, 1, 78, '2019-05-18 12:20:58', 2000, 'Headset', 0, 1500, 6),
(241, 189, 1, 82, '2019-05-18 12:22:11', 50, 'Buko ', 0, 25, 6),
(242, 189, 1, 79, '2019-05-18 12:22:11', 1000, 'Watcch Unisex', 0, 520, 6);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `background` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `background`, `logo`) VALUES
(1, '', 'logo213.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `address`, `contact`, `email`) VALUES
(8, 'EOM', 'test', 'test', 'dev.algermakiputin@gmail.com'),
(9, '123123', 'test', '123123', 'testing@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `account_type` varchar(50) NOT NULL,
  `date_created` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `account_type`, `date_created`, `created_by`) VALUES
(6, 'admin', '$2y$10$D5EzAbSDqhvdailkxdcMAunK0cs5Icipga.9v9Tu.oG9JKgO671Fa', 'Admin', '2017-07-07 02:10:21 am', 'admin'),
(20, 'cashier', '$2y$10$HZfKsARm0MAYsO8guWah0.hxIg9jLN1YKDeWUcWHi86/E7l/Hbpq.', 'Cashier', '2019-02-20 09:52:29 am', 'admin'),
(21, 'test123', '$2y$10$6guyx6ZPV7tVhjw/nWF32eEXEclBkQt0AfyevYFM/bFqv6IOsM/9K', 'Admin', '2019-06-01 06:11:53 pm', 'admin'),
(22, 'testtest', '$2y$10$FzEENHoetVssPbcXCBaCQ.qZqL2PYag0C6StPlZKcZzRkQ/6iYtxS', 'Admin', '2019-06-01 06:21:00 pm', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`customer_id`);

--
-- Indexes for table `delivery_details`
--
ALTER TABLE `delivery_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `barcode_2` (`barcode`),
  ADD KEY `barcode` (`barcode`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordering_level`
--
ALTER TABLE `ordering_level`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_description`
--
ALTER TABLE `sales_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `delivery_details`
--
ALTER TABLE `delivery_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1799;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ordering_level`
--
ALTER TABLE `ordering_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `sales_description`
--
ALTER TABLE `sales_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=243;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `supplier` (`id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `items_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`);

--
-- Constraints for table `ordering_level`
--
ALTER TABLE `ordering_level`
  ADD CONSTRAINT `ordering_level_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);

--
-- Constraints for table `prices`
--
ALTER TABLE `prices`
  ADD CONSTRAINT `prices_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
