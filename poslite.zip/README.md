# POS Sales and Inventory Management System

This system is developed in PHP using the Codeigniter framework. This very simple POS Sales and Inventory System is a computer software developed to simplify the business operation of a small retail store or shop, for accurate recording of sales, reduce workload, faster business transaction, and to manage inventory efficiently. 

